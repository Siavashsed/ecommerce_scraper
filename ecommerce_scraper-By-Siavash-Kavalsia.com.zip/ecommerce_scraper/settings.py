
BOT_NAME = 'ecommerce_scraper'

SPIDER_MODULES = ['ecommerce_scraper.spiders']
NEWSPIDER_MODULE = 'ecommerce_scraper.spiders'

ROBOTSTXT_OBEY = True
DOWNLOAD_DELAY = 1
AUTOTHROTTLE_ENABLED = True
