
import scrapy

class EcommerceScraperItem(scrapy.Item):
    email = scrapy.Field()
    url = scrapy.Field()
