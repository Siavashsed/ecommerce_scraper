
class EcommerceScraperPipeline:
    def process_item(self, item, spider):
        return item
