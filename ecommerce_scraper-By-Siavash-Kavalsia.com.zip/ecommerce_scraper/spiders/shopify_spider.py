
# Created by Siavash Sadighi, Kavalsia Inc. (https://kavalsia.com)

import scrapy
from urllib.parse import urljoin
import re

class ShopifySpider(scrapy.Spider):
    name = 'shopify_spider'
    allowed_domains = ["example.com"]
    start_urls = [
        'https://www.example-shopify-store.com/',
    ]

    def parse(self, response):
        page_text = response.text.lower()

        if "powered by shopify" in page_text or "cdn.shopify.com" in page_text:
            self.logger.info(f"Shopify store found: {response.url}")
            self.extract_emails(response)
        
        elif "woocommerce" in page_text or "wp-content/plugins/woocommerce" in page_text:
            self.logger.info(f"WooCommerce store found: {response.url}")
            self.extract_emails(response)
        
        elif any(keyword in page_text for keyword in ['cart', 'checkout']):
            self.logger.info(f"Possible eCommerce site found: {response.url}")
            self.extract_emails(response)
        
        links = response.css('a::attr(href)').getall()
        for link in links:
            next_page = urljoin(response.url, link)
            if next_page:
                yield scrapy.Request(next_page, callback=self.parse)

    def extract_emails(self, response):
        emails = re.findall(r'[\w\.-]+@[\w\.-]+\.\w+', response.text)
        for email in emails:
            yield {
                'email': email,
                'url': response.url,
            }
