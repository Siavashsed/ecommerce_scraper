
# Ecommerce Scraper

This project is a custom Python web scraper built using the Scrapy framework. It is designed to identify and scrape eCommerce websites powered by Shopify, WooCommerce, and other platforms.

## Credits
Created by: Siavash Sadighi  
Company: Kavalsia Inc.  
Website: [Kavalsia.com](https://kavalsia.com)
